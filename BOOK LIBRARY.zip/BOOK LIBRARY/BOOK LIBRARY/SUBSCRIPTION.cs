﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace BOOK_LIBRARY
{
    public class SUBSCRIPTION
    {
        [Key]
        public string SUBSCRIBER_NAME { get; set; }
        public DateTime DATE_SUBSCRIBED { get; set; }
        public DateTime DATE_RETURNED { get; set; }
        public string BOOK_ID { get; set; }
    }

    public class SubscribeOne
    {
        public string SUBSCRIBER_NAME { get; set; }
        public string BOOK_ID { get; set; }
        public DateTime DATE_SUBSCRIBED { get; set; }
    }
}
