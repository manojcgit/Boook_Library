﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BOOK_LIBRARY.Repository
{
    public class bookService : IbookService
    {
        private readonly BookDbContext _dbContext;

        public bookService(BookDbContext dbContext)
        {
            _dbContext = dbContext;
        }
        public async Task<List<BOOK>> getAllBook()
        {
            return await _dbContext.books
                .FromSqlRaw<BOOK>("pGetBookList")
                .ToListAsync();
        }
    }
}
