﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BOOK_LIBRARY.Repository
{
    public class subscriptionService : IsubscriptionService
    {
        private readonly BookDbContext _dbContext;

        public subscriptionService(BookDbContext dbContext)
        {
            _dbContext = dbContext;
        }

        public async Task<List<SUBSCRIPTION>> getAllSubscribe()
        {

            return await _dbContext.subscription
               .FromSqlRaw<SUBSCRIPTION>("pGetSubscriptionList")
               .ToListAsync();
        }
        public async Task<IEnumerable<BOOK>> GetSubscribeBookByIdAsync(string Bookid)
        {
            var BookDetails = await Task.Run(() => _dbContext.books
                                   .FromSqlRaw($"pBookAvailable @Bookid = '{Bookid}'").ToList());
            return BookDetails;
        }

        public async Task<int> AddSubScriptionAsync(SubscribeOne subscription)
        {
            var result = await _dbContext.Database.ExecuteSqlRawAsync($"exec pUpdateSubscription @SUBSCRIBER_NAME= '{subscription.SUBSCRIBER_NAME}',@DATE_SUBSCRIBED='{subscription.DATE_SUBSCRIBED}',@BOOK_ID= '{subscription.BOOK_ID}'");
            return result;
        }
    }
}
