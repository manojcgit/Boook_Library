﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BOOK_LIBRARY.Repository
{
    public interface IbookService
    {
        public Task<List<BOOK>> getAllBook();
    }
}
