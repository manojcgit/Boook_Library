﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BOOK_LIBRARY.Repository
{
    public interface IsubscriptionService
    {
        public Task<List<SUBSCRIPTION>> getAllSubscribe();
        public Task<IEnumerable<BOOK>> GetSubscribeBookByIdAsync(string Id);
        public Task<int> AddSubScriptionAsync(SubscribeOne sub);
    }
}
