﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;


namespace BOOK_LIBRARY
{
    public class BOOK
    {
        [Key]
        public string BOOK_ID { get; set; }
        public string BOOK_NAME { get; set; }
        public string AUTHOR { get; set; }
        public int AVAILABLE_COPIES { get; set; }
        public int TOTAL_COPIES { get; set; }
    }
}
