﻿using BOOK_LIBRARY.Repository;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BOOK_LIBRARY.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class SubscribeController : ControllerBase
    {
        private readonly IsubscriptionService subscriptionService;

        public SubscribeController(IsubscriptionService _subscriptionService)
        {
            this.subscriptionService = _subscriptionService;
        }

        [HttpGet]
        public async Task<List<SUBSCRIPTION>> Get()
        {
            try
            {
                return await subscriptionService.getAllSubscribe();
            }
            catch
            {
                throw;
            }
        }

        [HttpPost]
        public async Task<IActionResult> Post([FromBody] SubscribeOne subscription)
        {
            try
            {
                var response = await subscriptionService.GetSubscribeBookByIdAsync(subscription.BOOK_ID);

                if (response == null)
                {

                    return new ObjectResult(subscription) { StatusCode = StatusCodes.Status422UnprocessableEntity };
                }
                else
                {
                    var response2 = await subscriptionService.AddSubScriptionAsync(subscription);

                    return new ObjectResult(subscription) { StatusCode = StatusCodes.Status201Created };
                }

            }
            catch
            {
                throw;
            }


        }
    }
}
