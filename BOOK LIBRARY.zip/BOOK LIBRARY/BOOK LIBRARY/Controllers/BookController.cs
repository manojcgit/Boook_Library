﻿using BOOK_LIBRARY.Repository;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BOOK_LIBRARY.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class BookController : ControllerBase
    {

        private readonly IbookService bookService;

        public BookController(IbookService bookService)
        {
            this.bookService = bookService;
        }

        [HttpGet]
        public async Task<List<BOOK>> Get()
        {
            try
            {
                return await bookService.getAllBook();
            }
            catch
            {
                throw;
            }
        }

    }
}
